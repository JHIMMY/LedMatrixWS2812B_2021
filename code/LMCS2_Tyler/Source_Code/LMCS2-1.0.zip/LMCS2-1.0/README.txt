# LMCS2
LED Matrix Control Software 2

Setup

1. configure the arduino sketch to match your matrix setup.
2. upload the arduino sketch.
3. load the software and set the width and height.
4. create a new pixel order and save it.
5. connect to the arduino.
